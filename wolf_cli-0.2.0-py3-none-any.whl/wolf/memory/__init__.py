"""Wolf CLI memory and context storage"""
