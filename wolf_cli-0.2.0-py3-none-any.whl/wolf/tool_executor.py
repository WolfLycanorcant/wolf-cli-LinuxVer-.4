"""
Wolf CLI Tool Executor

Executes tool calls with validation, permission checks, and error handling.
"""

import json
from typing import Any, Dict

from .permission_manager import PermissionManager, RiskLevel
from .tool_registry import get_registry, ToolSchema
from .utils.validation import validate_tool_params
from .utils.logging_utils import log_tool, log_error, log_warn, log_debug
from .providers import file_ops, ps_client


class ToolExecutor:
    """Executes validated tool calls"""
    
    def __init__(self, permission_manager: PermissionManager):
        self.permission_manager = permission_manager
        self.registry = get_registry()
        self._bind_handlers()
    
    def _bind_handlers(self) -> None:
        """Bind tool handlers to registry"""
        # File operations
        self.registry.get("create_file").handler = file_ops.create_file
        self.registry.get("read_file").handler = file_ops.read_file
        self.registry.get("write_file").handler = file_ops.write_file
        self.registry.get("delete_file").handler = file_ops.delete_file
        self.registry.get("list_directory").handler = file_ops.list_directory
        self.registry.get("get_file_info").handler = file_ops.get_file_info
        self.registry.get("move_file").handler = file_ops.move_file
        self.registry.get("copy_file").handler = file_ops.copy_file
        
        # Shell & system
        self.registry.get("execute_command").handler = lambda command, **kwargs: ps_client.execute_powershell_command(command, **kwargs)
        self.registry.get("get_system_info").handler = lambda: ps_client.get_system_info()
    
    def execute(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool call
        
        Args:
            tool_name: Name of the tool
            params: Tool parameters
            
        Returns:
            Result dictionary
        """
        # Get tool schema
        tool = self.registry.get(tool_name)
        if not tool:
            error_msg = f"Unknown tool: {tool_name}"
            log_error(error_msg)
            return {
                "ok": False,
                "tool": tool_name,
                "error": error_msg,
            }
        
        # Parse arguments if they're a string
        if isinstance(params, str):
            try:
                params = json.loads(params) if params.strip() else {}
            except json.JSONDecodeError as e:
                log_error(f"Failed to parse tool arguments as JSON: {e}")
                return {
                    "ok": False,
                    "tool": tool_name,
                    "error": f"Invalid JSON arguments: {e}",
                }
        
        # Ensure params is a dict
        if not isinstance(params, dict):
            return {
                "ok": False,
                "tool": tool_name,
                "error": f"Parameters must be a dict, got {type(params).__name__}",
            }
        
        # Validate parameters
        is_valid, error_msg = validate_tool_params(params, tool.parameters)
        if not is_valid:
            log_error(f"Invalid parameters for {tool_name}: {error_msg}")
            return {
                "ok": False,
                "tool": tool_name,
                "input": params,
                "error": f"Invalid parameters: {error_msg}",
            }
        
        # Check permissions
        if not self.permission_manager.check_and_confirm(
            tool_name=tool_name,
            risk_level=tool.risk_level,
            params=params,
            description=tool.description
        ):
            log_warn(f"Permission denied for {tool_name}")
            return {
                "ok": False,
                "tool": tool_name,
                "input": params,
                "error": "Permission denied by user",
            }
        
        # Execute handler
        try:
            log_debug(f"Executing {tool_name} with params: {params}")
            result = tool.handler(**params)
            
            # Ensure result has 'ok' field
            if "ok" not in result:
                result["ok"] = result.get("success", True)
            
            return {
                "ok": result.get("ok", True),
                "tool": tool_name,
                "input": params,
                "result": result,
                "error": result.get("error"),
            }
        
        except Exception as e:
            log_error(f"Error executing {tool_name}: {str(e)}", exc_info=True)
            return {
                "ok": False,
                "tool": tool_name,
                "input": params,
                "error": str(e),
            }
