"""
Wolf CLI Wrapper

Main CLI entry point using Click and Rich for Wolf CLI.
Provides the 'wolf' command to chat with LLM and execute tools.
"""

import sys
from typing import List, Optional, Tuple
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from .config_manager import get_config
from .permission_manager import PermissionManager, TrustLevel
from .tool_registry import get_registry
from .tool_executor import ToolExecutor
from .orchestrator import Orchestrator
from .utils.logging_utils import setup_logging, console as log_console


console = Console()


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--safe", is_flag=True, help="Enable safe mode (strict permissions, read-only).")
@click.option("--auto", is_flag=True, help="Allow automatic tool execution (permissive, no confirmations).")
@click.option("--image", "images", multiple=True, type=click.Path(exists=True, dir_okay=False, readable=True), help="Path(s) to image(s) for vision input.")
@click.option("--provider", type=click.Choice(["ollama", "openrouter"], case_sensitive=False), default="ollama", show_default=True, help="LLM provider to use.")
@click.option("--model", type=str, default=None, help="LLM model to use (overrides config).")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging (DEBUG level).")
@click.option("--list-tools", is_flag=True, help="List available tools and exit.")
@click.argument("prompt", nargs=-1)
def wolf(
    safe: bool,
    auto: bool,
    images: Tuple[str, ...],
    provider: str,
    model: Optional[str],
    verbose: bool,
    list_tools: bool,
    prompt: Tuple[str, ...]
) -> None:
    """
    Wolf CLI - AI-powered command-line tool with vision and tool calling
    
    Examples:
    
      wolf "create a file named test.txt with hello world"
      
      wolf --image screenshot.png "what's in this image?"
      
      wolf --auto "list all python files in current directory"
      
      wolf --safe "show me system information"
    """
    # Check for mutually exclusive flags
    if safe and auto:
        console.print("[red]Error:[/red] --safe and --auto are mutually exclusive.")
        sys.exit(2)
    
    try:
        # Setup logging
        log_dir = Path.home() / ".wolf" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "wolf-cli.log"
        setup_logging(log_file=log_file, verbose=verbose)
        
        # Load configuration
        config = get_config()
        config.ensure_initialized()
        
        # Initialize core components
        registry = get_registry()
        
        # Determine trust level
        if safe:
            trust_level = TrustLevel.SAFE_ONLY
        elif auto:
            trust_level = TrustLevel.AUTO
        else:
            # Use configured default or interactive
            trust_level_str = config.get("default_trust_level", "interactive")
            trust_level = TrustLevel(trust_level_str)
        
        # Initialize permission manager
        permission_manager = PermissionManager(
            trust_level=trust_level,
            custom_allowlist=config.get("custom_allowlist", []),
            custom_denylist=config.get("custom_denylist", []),
        )
        
        # Initialize tool executor
        tool_executor = ToolExecutor(permission_manager=permission_manager)
        
        # Handle --list-tools
        if list_tools:
            _print_tools(registry)
            return
        
        # Validate prompt
        if not prompt:
            console.print("[yellow]No prompt provided.[/yellow]")
            console.print("\nUsage examples:")
            console.print("  wolf \"create a file named test.txt\"")
            console.print("  wolf --image photo.jpg \"describe this image\"")
            console.print("  wolf --list-tools")
            sys.exit(1)
        
        # Join prompt parts
        user_prompt = " ".join(prompt)
        
        # Get max tool iterations from config
        max_iterations = config.get("max_tool_iterations", 6)
        
        # Initialize orchestrator
        orchestrator = Orchestrator(
            tool_executor=tool_executor,
            provider=provider,
            model=model,
            max_tool_iterations=max_iterations,
        )
        
        # Run orchestration
        console.print(f"[cyan]🐺 Wolf CLI[/cyan] - Provider: {provider}, Model: {orchestrator.model}")
        console.print()
        
        result = orchestrator.run(
            prompt=user_prompt,
            images=list(images) if images else None
        )
        
        # Display result
        if result.get("ok"):
            assistant_text = result.get("text", "")
            if assistant_text:
                console.print("[green]Assistant:[/green]")
                console.print(assistant_text)
            else:
                console.print("[yellow]Assistant provided no text response.[/yellow]")
            sys.exit(0)
        else:
            error_msg = result.get("error", "Unknown error")
            console.print(f"[red]Error:[/red] {error_msg}")
            sys.exit(1)
    
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(130)
    
    except Exception as exc:
        console.print(f"[red]Fatal error:[/red] {exc}")
        if verbose:
            import traceback
            console.print("\n[dim]Traceback:[/dim]")
            console.print(traceback.format_exc())
        sys.exit(1)


def _print_tools(registry) -> None:
    """Print available tools in a formatted table"""
    table = Table(title="🐺 Wolf CLI - Available Tools")
    table.add_column("Tool Name", style="cyan", no_wrap=True)
    table.add_column("Description", style="white")
    table.add_column("Risk Level", style="magenta")
    
    # Get tools by category
    categories = registry.list_by_category()
    
    for category, tool_names in categories.items():
        if tool_names:
            # Add category header
            table.add_row(f"[bold]{category}[/bold]", "", "")
            
            # Add tools in category
            for name in sorted(tool_names):
                tool = registry.get(name)
                if tool:
                    risk = tool.risk_level.value if hasattr(tool.risk_level, 'value') else str(tool.risk_level)
                    # Truncate long descriptions
                    desc = tool.description
                    if len(desc) > 80:
                        desc = desc[:77] + "..."
                    table.add_row(f"  {name}", desc, risk)
    
    console.print(table)
    console.print(f"\n[dim]Total tools: {len(registry.list_tools())}[/dim]")


def main():
    """Entry point for console script."""
    wolf()


if __name__ == "__main__":
    wolf()
