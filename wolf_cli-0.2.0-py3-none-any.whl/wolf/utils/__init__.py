"""Wolf CLI utilities"""
